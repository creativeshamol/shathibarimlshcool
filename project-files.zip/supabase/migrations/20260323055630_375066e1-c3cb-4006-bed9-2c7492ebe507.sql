
ALTER TABLE public.notices ADD COLUMN file_url text;

INSERT INTO storage.buckets (id, name, public) VALUES ('notice-attachments', 'notice-attachments', true);

CREATE POLICY "Anyone can view notice attachments"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'notice-attachments');

CREATE POLICY "Admins can upload notice attachments"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'notice-attachments' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete notice attachments"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'notice-attachments' AND public.has_role(auth.uid(), 'admin'));
